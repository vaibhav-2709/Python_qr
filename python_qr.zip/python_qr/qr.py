import qrcode
from PIL import Image

upi_id = "trivedivaibhav0111@okhdfcbank"  
name = "Vaibhav Dutt Trivedi"  
amount = ""  

upi_url = f"upi://pay?pa={upi_id}&pn={name}&am={amount}&cu=INR"

qr = qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=6,
    border=10,
)
qr.add_data(upi_url)
qr.make(fit=True)

img = qr.make_image(fill_color="red", back_color="white")
img.save("google_pay_qr.png")

print("Google Pay QR code generated and saved as google_pay_qr.png")
